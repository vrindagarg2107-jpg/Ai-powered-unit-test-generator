# CodeCrafters — AI-Powered Unit Test Generator

A local Flask web prototype for SCSE4041 Milestone 2.

## Features
- Source-code input and language/framework selection
- Three prompt versions (baseline, context-aware, validation-focused)
- Demo mode with heuristic function detection and a clearly labeled test-plan template
- Optional Gemini API mode
- Structured test-case matrix and generated-code display
- Optional local pytest validation for Python

## Run locally (Windows PowerShell)
1. Install Python 3.10 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Create and activate a virtual environment:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```
4. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Start the app:
   ```powershell
   python app.py
   ```
6. Open http://127.0.0.1:5000

## Enable actual Gemini generation
1. Create an API key in Google AI Studio.
2. Set it in the same terminal before starting the app:
   ```powershell
   $env:GEMINI_API_KEY="YOUR_API_KEY"
   $env:GEMINI_MODEL="gemini-2.5-flash"
   python app.py
   ```
3. Select "Gemini AI mode (API key required)" in the app.

Do not paste your API key into the browser, source code, GitHub, report, or reel. Keep it in an environment variable. API access may require billing or quota availability.

## Important academic honesty notes
- Demo mode is a heuristic demonstration, not an LLM and not proof of AI-generated tests.
- Gemini mode only works after a valid API key is configured and a real request succeeds.
- The generated tests must be reviewed and actually executed. Do not report unrun tests as Pass.
- Prompt versions included here are candidate drafts. Your iteration log must record which versions your team actually tested, what changed, why, and observed outcomes.
- The validation endpoint is an educational local runner with basic denylist checks, NOT a hardened security sandbox. Run only code you trust. Do not expose this server publicly.
- The app runs on localhost. It is not automatically hosted online and does not create a public prototype URL.

## Suggested demo sample
```python
def divide(a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b

def is_even(number):
    return number % 2 == 0
```
